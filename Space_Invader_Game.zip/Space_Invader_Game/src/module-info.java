/**
 * 
 */
/**
 * 
 */
module Space_Invader_Game {
	requires java.desktop;
}