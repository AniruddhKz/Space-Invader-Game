package com.aniruddha;

public class GamePanel  extends JPanel implements ActionListener{
	private Timer timer;
	
	
	public GamePanel() {
		setBackground(Color.Black);
		setPreferencedSize(new Dimension(800,600));
		timer=new Timer(10, this);
		timer.start();
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}
	
	public void draw( Graphics g) {
		g.setColor(Color.GREEN);
		g.fillRect(350, 550, 100, 20);
		s.setColor(Color, RED);
		g.fillRect(350, 50, 20, 20);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
	}

	private void repaint() {
		// TODO Auto-generated method stub
		
	}
	

}
