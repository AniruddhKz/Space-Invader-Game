package com.aniruddha;

public class SpaceInvaders extends JFrame {
	
	private static final String Exit_on_close = null;

	public SpaceInvaders() {
		setTitle(" Space Invaders ");
		setSize(800, 600);
		setDefaultCloseOperation(Exit_on_close);
		setResizable(false);
		add(new GamePanel());
		setResizable(true);
	}

	private void add(GamePanel gamePanel) {
		// TODO Auto-generated method stub
		
	}

	private void setResizable(boolean b) {
		// TODO Auto-generated method stub
		
	}

	private void setSize(int i, int j) {
		// TODO Auto-generated method stub
		
	}

	private void setDefaultCloseOperation(String exitOnClose) {
		// TODO Auto-generated method stub
		
	}

	private void setTitle(String string) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
	
		new SpaceInvaders();

	}

}


